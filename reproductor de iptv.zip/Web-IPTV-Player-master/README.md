# Web IPTV Player
## Edit config.php according to your site
## You can add or remove links by editing *.php

# http://iptvde.mypressonline.com

## View
![Demo](https://raw.githubusercontent.com/telase/Web-IPTV-Player/master/view1.jpg)
![Demo](https://raw.githubusercontent.com/telase/Web-IPTV-Player/master/view.jpg)


## and Under Development
http://mstrall.epizy.com/demo/

and Youtube launch
https://www.youtube.com/watch?v=jgLFcEOLG88
--------------------------------------

(Your Upload) Upload desired m3u list
--------------------------------------
No need to write and edit links one by one
------------------------------------------
Just add m3u link into php and auto pull list
---------------------------------------------

![Demo](https://raw.githubusercontent.com/telase/Web-IPTV-Player/master/developed.jpg)


