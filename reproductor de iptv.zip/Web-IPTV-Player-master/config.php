<?php
#Config file
//Site Title
$title = "IPTV Video Streaming Website";

//Site URL
$site_url = "http://iptvde.mypressonline.com/";

//Site Description
$description = "";

//Watermark image
$watermarkImage = "";

//Watermark link
$watermarkLink = "";

//Google Analytics tag ID
$gaCode = "UA-69771681-1";

//Preroll Ads Video (.mp4)
$prerollAds = "https://raw.githubusercontent.com/telase/PRO/master/vids/flash.mp4";

//Preroll Ads Time (seconds)
$prerollTime = 3;

//Preroll Ads External Link
$prerollLink = "";
?>